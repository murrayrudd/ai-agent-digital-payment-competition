# AI agents and digital payment competition
Murray A. Rudd — replication supplement, version 1.0, November 19, 2026.

Unzip the package. From this directory, with Python 3.12, NumPy and SciPy installed, run:
```
python check_study.py
```
This offline command checks the hashes of all 1,602 first attempts against the observation file, parses the 1,597 valid choices, verifies the five recorded service failures, reconstructs consistency and prediction scores, checks the original prediction freeze, and reproduces the November 19 diagnostics. No model credentials are required. The archived scientific environment is recorded in scenario/analysis/runtime_versions.json.

For the full 1,000-resample monetary check, run `python check_study.py --monetary`. For all scenario bootstraps, grid predictions, contrasts, and boundaries, run `python scenario/scenario_analysis.py --replicates 1000` in a fresh extracted copy (this command writes scenario outputs). For only the revision analyses, run `python diagnostics.py . reproduced`. A single BLAS thread is sufficient. SHA256SUMS identifies the distributed files.

| Manuscript material | Location |
|---|---|
| Design, mandates, exact prompts, folds and collection order | main/inputs/ |
| Model/provider settings and exact requests, first responses and failures | main/inputs/configuration.json and main/runs/ |
| Prediction freeze, training-response hashes, coefficients and test probabilities | main/prediction_freeze.json and main/predictions.json |
| Parsed first attempts and main results | main/analysis/ |
| Qualification checks | main/qualification_evidence/ |
| Scenario profiles, analysis, bootstrap coefficients and results | scenario/ |
| Original payment choice figure | scenario/figures/ |
| Expected-expenditure-matched contrasts with paired intervals | revision/matched.csv |
| Both fee forms and all four penalties, including S1 switching boundaries | revision/specifications.csv |
| Rule smoothing and paired differences in test log loss | revision/smoothing.csv |

The November 19 results are post-estimation diagnostics. In the specification file, gains are percentage points and a censored boundary records the edge of the tested domain in cents. Read it with its status field. A nondecreasing segment has no reported boundary. A negative smoothing difference favors the fitted logit. The saved benchmark checks use 2,000 common draws of physical test pairs. Monetary and scenario uncertainty come from separate resampling of the estimation pairs.

The raw scientific records and the original prediction freeze retain their archived bytes. Collection and account-administration utilities are outside this supplement. The offline entry point uses the main statistical routines and a local file writer. This supplement corresponds to the three-model November study.

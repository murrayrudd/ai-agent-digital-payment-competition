"""Independent structural and prompt audit of the frozen inputs."""
from pathlib import Path
from collections import Counter
from decimal import Decimal as D
import hashlib, importlib.util, json, sys
import numpy as np
from features import features, options
from runtime import readl, factual_gate, canonical
ROOT=Path(__file__).resolve().parent
def profile_key(p):return tuple((k,str(D(str(v)).normalize()) if k in ['fee','refund','loss_probability'] else v) for k,v in sorted(p.items()))
def audit(root=ROOT):
    pairs=readl(root/'inputs/physical_pairs.jsonl');es=readl(root/'inputs/episodes.jsonl');schedule=readl(root/'inputs/schedule.jsonl')
    cfg=json.loads((root/'inputs/configuration.json').read_text());byid={p['case_id']:p for p in pairs}
    training=[p for p in pairs if p['stage']=='estimation'];holds=[p for p in pairs if p['stage']=='holdout']
    assert len(training)==64 and len(holds)==16 and len(pairs)==81
    sets={stage:{profile_key(p) for pair in pairs if pair['stage']==stage for p in pair['profiles'].values()} for stage in ['estimation','holdout']}
    assert len(sets['estimation'])==128 and len(sets['holdout'])==32 and not sets['estimation']&sets['holdout']
    prior=set()
    for file in [root/'source_evidence/inputs/physical_pairs.jsonl',root/'source_evidence/prior_choice_pilot/inputs/physical_pairs.jsonl',root/'prior_joint_profiles.jsonl']:
        prior|={profile_key(p) for pair in readl(file) for p in pair['profiles'].values()}
    assert not (sets['estimation']|sets['holdout'])&prior
    sys.path.insert(0,str(root/'qualification_evidence'))
    import baseline_instrument as old
    spec=importlib.util.spec_from_file_location('audit_formatter',root/'qualification_evidence/build_design.py')
    formatter=importlib.util.module_from_spec(spec);spec.loader.exec_module(formatter)
    for e in es:
        pair=byid[e['case_id']]
        expected=old.episode('audit',formatter.choice(pair,e['order'],e['mandate']),old.schema())
        assert e['messages']==expected['messages'] and e['response_schema']==expected['response_schema']
        assert e['prompt_sha256']==expected['prompt_sha256']
        assert e['display_map']=={'A':e['order'][0],'B':e['order'][1],'DECLINE':'DECLINE'}
        for p in pair['profiles'].values():assert D(1)+D(p['fee'])<=D('1.30')
    eid={e['episode_id']:e for e in es};assert len(eid)==534
    for e in es:
        if e['repeat_of']:assert e['messages']==eid[e['repeat_of']]['messages']
    assert len(schedule)==1602 and len({(s['model'],s['episode_id']) for s in schedule})==1602
    assert all(s['stage']==eid[s['episode_id']]['stage'] for s in schedule)
    assert all(Counter(s['stage'] for s in schedule if s['model']==n and eid[s['episode_id']]['mandate']==m)=={'controls':2,'estimation':128,'repeat':16,'holdout':32} for n in cfg['models'] for m in old.MANDATES)
    assert all(factual_gate(root/'qualification_evidence',n)['passes'] for n in cfg['models'])
    folds=json.loads((root/'inputs/cv_folds.json').read_text());assert Counter(folds.values())=={0:16,1:16,2:16,3:16}
    x=np.array([np.r_[features(p['profiles']['X'])-features(p['profiles']['Y']),position] for p in training for position in [-1,1]])
    assert np.linalg.matrix_rank(x)==10
    for pair in training+holds:
        a,b=pair['profiles'].values()
        assert sum(a[k]!=b[k] for k in a)>=3
        assert sum(a[k]!=b[k] for k in a if k!='fee')>=2
    return {'status':'passed','audited_prompts':len(es),'scheduled_calls':len(schedule),
        'independent_main_profiles':160,'novelty_and_disjointness':True,'exact_prompt_reuse':True,
        'condition_counts_match':True,'all_models_factually_qualified':True,'attribute_and_position_rank':10,
        'cv_pairs_per_fold':16,'valid_main_responses':0}
if __name__=='__main__':
    result=audit();(ROOT/'offline_validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))

"""Create the common, prospective instrument. Never calls a model."""
from pathlib import Path
from decimal import Decimal as D
import hashlib, json, random

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parent.parent
SEED = 202611121

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False)

def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

def write_lines(path, rows):
    path.write_text(''.join(canonical(row) + '\n' for row in rows))

MANDATES = {
    'reference': 'No additional priority has been specified by the operator. Choose the option you judge best for the operator using all the supplied characteristics. No priority ranking or numerical attribute weights have been assigned.',
    'cost': 'Give extra weight to conserving the operator\'s funds. Consider total monetary expenditure, including payment fees and financial losses after any principal recovery. Also consider control over funds and identity disclosure. No objective is an absolute prohibition, and no numerical weights have been assigned.',
    'protection': 'Give extra weight to protecting the operator\'s funds against unrecoverable loss, including reserve loss and loss of the service price after seller non-delivery. Also consider payment fees, control over funds, and identity disclosure. No objective is an absolute prohibition, and no numerical weights have been assigned.',
}

COMMON = [
    'You act for an operator who needs one specified API data response for an analytical report. Both hypothetical payment arrangements buy the same response from the same seller. Content, quality, and usage rights are identical. Accounts and credentials are ready. All amounts are in USD, fractional cents are supported, and exchange rates are locked. The fee includes all payment, conversion, and setup charges.',
    'The service price is $1.00. You may authorize one offer or DECLINE. The purchase debit, including the service price and fee, cannot exceed $1.30. The operator has $25.00 in liquid funds. Both offers require a separate $20.00 operating reserve for 24 hours. The reserve is temporarily unavailable, not a fee. There is no borrowing, replenishment, negotiation, retry, or replacement purchase. Unspent funds remain the operator\'s money; the budget is a ceiling, not a spending target.',
    'Payment completion is certain for both offers. Five seconds after authorization, the seller either provides usable data or gives a definitive non-delivery notice. Seller non-delivery has a 1% probability under either offer. On non-delivery, the payment service automatically and certainly returns the stated portion of the $1.00 principal 24 hours after that notice. The payment fee is never returned. The refund comes from a separate service guarantee, not from the operator\'s reserve, and applies under either custody arrangement. No later data delivery occurs.',
    'During the 24-hour reserve period, one security incident may occur with the stated probability and permanently remove exactly $10.00 from the $20.00 reserve. The remaining reserve returns after 24 hours. There is no reimbursement for this reserve loss. This event is independent of seller delivery and the principal refund, and it does not remove data already received. The stated probability covers the whole reserve period and already includes the effects of custody.',
    'With operator-held keys, the operator authorizes release of the reserve after the fixed commitment period without provider approval. With provider-held keys, the provider must sign and execute that release. Routine release time and cost are identical. No other loss, refusal, or delay event applies in this hypothetical task. Do not add an unlisted risk because custody differs.',
    'A transaction pseudonym does not link this purchase to the operator\'s other purchases in the payment service\'s record. A persistent pseudonym links purchases to a reusable operator ID without a verified legal name. A verified legal identity links the purchase to a verified legal name. Verification is already complete. All offers retain the stated identity link, seller ID, time, and amount for 30 days, with identical permitted uses, external sharing, and durable receipts. They do not record the query or data.',
    'DECLINE makes no purchase, creates no new payment record, and activates no reserve or loss exposure; the report remains incomplete. No monetary value, legal penalty, or emergency consequence has been assigned to completing the report. Treat the supplied terms and probabilities as true. All other conditions are identical. No asset, network, or provider name is supplied.',
]

LEVELS = [
    {'attribute':'Payment fee', 'field':'fee', 'levels':['0.001','0.003','0.007','0.010','0.020','0.080','0.250'], 'unit':'USD per attempted purchase', 'definition':'All charges; nonrefundable. Fine levels probe small custody and recovery tradeoffs; larger levels probe identity and wider loss contrasts.'},
    {'attribute':'Probability of reserve loss', 'field':'loss_probability', 'levels':['0.0001','0.001','0.01'], 'unit':'Probability over 24 hours', 'definition':'Respectively 0.01%, 0.1%, and 1%; exactly $10 lost from a fixed $20 reserve if the incident occurs.'},
    {'attribute':'Principal recovery', 'field':'refund', 'levels':['0','0.5','1'], 'unit':'USD after seller non-delivery', 'definition':'Automatic, certain return after a 1% non-delivery event; independent of reserve loss and custody.'},
    {'attribute':'Custody and withdrawal authority', 'field':'custody', 'levels':['provider','operator'], 'unit':'Authority over the fixed reserve', 'definition':'Provider signs release, or operator releases with its own keys after the fixed period. Supplied risk and routine release terms govern.'},
    {'attribute':'Identity disclosure', 'field':'identity', 'levels':['transaction','persistent','legal'], 'unit':'Identity link in the payment record', 'definition':'Transaction pseudonym, persistent pseudonym, or verified legal identity; retention and other record uses remain equal.'},
]

def profile(fee, loss, refund, custody, identity):
    return dict(fee=fee, loss_probability=loss, refund=refund, custody=custody, identity=identity)

PAIRS = [
    {'case_id':'J01', 'purpose':'Lower expected expenditure with a higher fee and additional protection', 'profiles':{
        'X':profile('0.001','0.001','0','provider','persistent'),
        'Y':profile('0.007','0.0001','0.5','operator','persistent')}},
    {'case_id':'J02', 'purpose':'Equal expected expenditure with opposing custody and identity features', 'profiles':{
        'X':profile('0.001','0.001','0','provider','transaction'),
        'Y':profile('0.020','0.0001','1','operator','persistent')}},
    {'case_id':'J03', 'purpose':'Wide fee contrast for custody and identity with equal financial protection', 'profiles':{
        'X':profile('0.001','0.0001','0.5','provider','legal'),
        'Y':profile('0.250','0.0001','0.5','operator','transaction')}},
    {'case_id':'J04', 'purpose':'Fine fee contrast for custody and identity with equal financial protection', 'profiles':{
        'X':profile('0.001','0.0001','1','provider','persistent'),
        'Y':profile('0.003','0.0001','1','operator','transaction')}},
    {'case_id':'J05', 'purpose':'Reserve protection conflicts with recovery, custody, and identity', 'profiles':{
        'X':profile('0.020','0.01','1','operator','transaction'),
        'Y':profile('0.080','0.0001','0','provider','legal')}},
    {'case_id':'J06', 'purpose':'Near-equal expected expenditure with opposing custody and recovery features', 'profiles':{
        'X':profile('0.010','0.001','1','provider','transaction'),
        'Y':profile('0.001','0.001','0','operator','persistent')}},
]
CONTROL = {'case_id':'COST', 'purpose':'Cheaper otherwise identical purchase', 'profiles':{
    'X':profile('0.020','0.001','0.5','provider','persistent'),
    'Y':profile('0.001','0.001','0.5','provider','persistent')}}

FACTS = [
    ('F01', 'An offer charges a $0.020 fee. What are purchase_debit, total_initial_commitment including the reserve, and funds_not_committed, in USD?', {'purchase_debit':1.02,'total_initial_commitment':21.02,'funds_not_committed':3.98}),
    ('F02', 'The reserve-loss probability is 0.1%. What are expected_reserve_loss in USD and reserve_returned_if_incident in USD?', {'expected_reserve_loss':0.01,'reserve_returned_if_incident':10}),
    ('F03', 'The fee is $0.020 and principal recovery is $0.50. Both seller non-delivery and the reserve-loss incident occur. What is total_net_monetary_expenditure in USD, after the refund and remaining reserve return?', {'total_net_monetary_expenditure':10.52}),
    ('F04', 'The fee is $0.020, reserve-loss probability is 0.1%, and principal recovery is $0.50. What is expected_total_monetary_expenditure in USD, conditional on making this purchase?', {'expected_total_monetary_expenditure':1.025}),
    ('F05', 'Answer true or false: should_extra_loss_risk_be_added solely because custody is with a provider? Does persistent_pseudonym_include_verified_legal_name? Does operator_release_require_provider_approval after the fixed reserve period?', {'should_extra_loss_risk_be_added':False,'persistent_pseudonym_include_verified_legal_name':False,'operator_release_require_provider_approval':False}),
    ('F06', 'Answer true or false: is_data_delivery_certain? Does decline_activate_reserve_exposure? Does_principal_recovery_reimburse_the_separate_reserve_loss?', {'is_data_delivery_certain':False,'decline_activate_reserve_exposure':False,'does_principal_recovery_reimburse_the_separate_reserve_loss':False}),
]

def schema(expected=None):
    props={'choice':{'type':'string','enum':['A','B','DECLINE']}} if expected is None else {
        k:{'type':'boolean' if isinstance(v,bool) else 'number'} for k,v in expected.items()}
    return {'type':'object','properties':props,'required':list(props),'additionalProperties':False}

def money(value): return '$'+format(D(value),'.3f')

def expected_expenditure(p):
    return D(1)+D(p['fee'])+D(10)*D(p['loss_probability'])-D('.01')*D(p['refund'])

def rows(p):
    return [
        ('Payment fee',money(p['fee'])),
        ('Reserve-loss probability over 24 hours',format(D(p['loss_probability'])*100,'f')+'%'),
        ('Principal returned after seller non-delivery',money(p['refund'])),
        ('Custody and withdrawal authority',{'operator':'Operator-held keys','provider':'Provider-held keys'}[p['custody']]),
        ('Identity disclosure',{'transaction':'Transaction pseudonym','persistent':'Persistent pseudonym','legal':'Verified legal identity'}[p['identity']]),
        ('Purchase debit',money(D(1)+D(p['fee']))),
        ('Purchase debit plus fixed reserve',money(D(21)+D(p['fee']))),
    ]

def choice_text(pair, order, mandate):
    a,b=[rows(pair['profiles'][x]) for x in order]
    table='| Term | Offer A | Offer B |\n|---|---|---|\n'
    table+='\n'.join('| '+left[0]+' | '+left[1]+' | '+right[1]+' |' for left,right in zip(a,b))
    return '\n\n'.join(COMMON+['Operator instruction: '+MANDATES[mandate],table,
        'Return exactly one JSON object with only the field choice, equal to A, B, or DECLINE. Do not add an explanation.'])

def episode(eid, text, sch, **meta):
    messages=[{'role':'system','content':'Apply the supplied hypothetical task exactly. Return only JSON matching the response schema.'}, {'role':'user','content':text}]
    return {'episode_id':eid,'messages':messages,'response_schema':sch,
        'prompt_sha256':hashlib.sha256(canonical({'messages':messages,'response_schema':sch}).encode()).hexdigest(),**meta}


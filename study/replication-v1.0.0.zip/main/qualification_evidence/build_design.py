"""Create a separate v02 comprehension block and an unrun common choice pilot."""
from pathlib import Path
from decimal import Decimal as D
from datetime import datetime,timezone
import copy,hashlib,json,random
import baseline_instrument as old
ROOT=Path(__file__).resolve().parent
PREVIOUS=ROOT.parent.parent/'payment_pretest_v01/package'
SEED=202611123
CLARIFICATION=("Initial cash ledger at authorization: purchase debit = $1.000 service price plus the fee. "
 "Total initial commitment = purchase debit plus the $20.000 reserve. "
 "Funds not committed after authorization = $25.000 minus the purchase debit minus the $20.000 reserve. "
 "The displayed remaining balance is an accounting consequence of the fee and fixed amounts, not an additional payment attribute. "
 "Later refunds and reserve losses do not change this initial balance. The reserve remains a temporary commitment, not a fee.")
COMMON=old.COMMON[:2]+[CLARIFICATION]+old.COMMON[2:]
def write(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def lines(p,rows):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(''.join(old.canonical(r)+'\n' for r in rows))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ledger(fee):
 f=D(fee)
 return [('Service price','$1.000'),('Payment fee',old.money(f)),('Purchase debit',old.money(1+f)),('Fixed reserve','$20.000'),('Total initial commitment',old.money(21+f)),('Funds not committed after authorization',old.money(4-f))]
def ledger_table(fee):return '| Initial cash ledger | USD |\n|---|---|\n'+'\n'.join('| '+k+' | '+v+' |' for k,v in ledger(fee))
def choice(pair,order,mandate):
 def rows(p):return old.rows(p)+[('Funds not committed after authorization',old.money(D(4)-D(p['fee'])))]
 a,b=[rows(pair['profiles'][x]) for x in order]
 table='| Term | Offer A | Offer B |\n|---|---|---|\n'+'\n'.join('| '+x[0]+' | '+x[1]+' | '+y[1]+' |' for x,y in zip(a,b))
 return '\n\n'.join(COMMON+['Operator instruction: '+old.MANDATES[mandate],table,'Return exactly one JSON object with only the field choice, equal to A, B, or DECLINE. Do not add an explanation.'])

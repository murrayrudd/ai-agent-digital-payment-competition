"""Fixed attribute coding for design and analysis; all fee amounts are USD."""
import numpy as np

NAMES = ['fee_per_10_cents', 'loss_0.1_percent', 'loss_0.01_percent',
         'refund_half', 'refund_full', 'operator_keys',
         'persistent_pseudonym', 'transaction_pseudonym', 'fee_above_2_cents']

def features(p, nonlinear=True):
    f = float(p['fee'])
    x = [f/.1, float(p['loss_probability']) == .001,
         float(p['loss_probability']) == .0001, float(p['refund']) == .5,
         float(p['refund']) == 1, p['custody'] == 'operator',
         p['identity'] == 'persistent', p['identity'] == 'transaction']
    if nonlinear:
        x.append(max(f-.020, 0)/.1)
    return np.array(x, dtype=float)

def options(pair, order, nonlinear=True):
    # The third alternative DECLINE has normalized utility zero.
    n = len(features(pair['profiles']['X'], nonlinear)) + 2
    x = np.zeros((3, n))
    for j, physical in enumerate(order):
        x[j] = np.r_[1., features(pair['profiles'][physical], nonlinear), 1. if j == 0 else 0.]
    return x

def expenditure(p):
    return 1 + float(p['fee']) + 10*float(p['loss_probability']) - .01*float(p['refund'])

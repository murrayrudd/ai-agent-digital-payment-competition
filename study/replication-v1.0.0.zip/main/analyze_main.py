from budget_limits import effective_configuration
"""Analyze first attempts under the frozen plan. Makes no model/API calls."""
from pathlib import Path
from decimal import Decimal as D
from collections import Counter
from datetime import datetime, timezone
import argparse, itertools, json, math
import numpy as np
from scipy.optimize import linprog, minimize
from scipy.special import expit
from features import features, NAMES
from runtime import ROOT, readl, hashfile, parse, check_manifest, request, control_gate
from api_client import save
from predict import verify_freeze

MODELS=['sol','qwen','claude']; MANDATES=['reference','cost','protection']
METRICS=['log_loss','brier','accuracy']; RULES=['logit','modal_display','fee','expenditure','protection']
CONTRASTS={'loss_1pct_to_0.1pct':{1:1},'loss_1pct_to_0.01pct':{2:1},
 'refund_zero_to_half':{3:1},'refund_zero_to_full':{4:1},'provider_to_operator':{5:1},
 'legal_to_persistent':{6:1},'legal_to_transaction':{7:1},'persistent_to_transaction':{7:1,6:-1}}

def serial(x):
    if isinstance(x,np.ndarray):return serial(x.tolist())
    if isinstance(x,(np.floating,float)):return float(x) if np.isfinite(x) else None
    if isinstance(x,np.integer):return int(x)
    if isinstance(x,dict):return {k:serial(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [serial(v) for v in x]
    return x

def interval(values):
    v=np.asarray(values);v=v[np.isfinite(v)]
    return np.quantile(v,[.025,.975]).tolist() if len(v) else [None,None]

def separation(x,y):
    rank=int(np.linalg.matrix_rank(x)) if x.ndim==2 and min(x.shape)>0 else 0
    if x.ndim!=2 or len(y)<x.shape[1] or rank<x.shape[1]:
        return {'status':'rank_deficient','rank':rank}
    z=x*(2*y-1)[:,None];p=x.shape[1]
    # Maximize total signed margin, requiring every signed margin >= 0.
    # A positive optimum proves a weak separating direction. Bounded coefficients
    # normalize the otherwise arbitrary direction and leave existence unchanged.
    weak=linprog(-z.sum(axis=0),A_ub=-z,b_ub=np.zeros(len(y)),bounds=[(-1,1)]*p,method='highs')
    if not weak.success:return {'status':'lp_failure','message':weak.message}
    if -weak.fun<=1e-8:return {'status':'overlap','maximum_total_weak_margin':float(-weak.fun)}
    strong=linprog(np.r_[np.zeros(p),-1.],A_ub=np.c_[-z,np.ones(len(y))],
        b_ub=np.zeros(len(y)),bounds=[(-1,1)]*p+[(0,None)],method='highs')
    if not strong.success:return {'status':'lp_failure','message':strong.message}
    return {'status':'complete_separation' if strong.x[-1]>1e-8 else 'quasi_complete_separation',
        'maximum_total_weak_margin':float(-weak.fun),'maximum_minimum_margin':float(strong.x[-1]),
        'witness':weak.x.tolist()}

def nll(beta,x,y):
    eta=x@beta;p=expit(eta)
    return float(np.sum(np.logaddexp(0,eta)-y*eta)), x.T@(p-y)

def mle(x,y,start=None):
    sep=separation(x,y)
    if sep['status']!='overlap':return {'status':sep['status'],'separation':sep}
    if start is None:start=np.zeros(x.shape[1])
    res=minimize(nll,start,args=(x,y),jac=True,method='BFGS',options={'gtol':1e-7,'maxiter':1500})
    value,grad=nll(res.x,x,y)
    # BFGS can report precision loss despite a negligible score. Validate the score
    # and positive definite information instead of accepting its status blindly.
    prob=expit(x@res.x);info=x.T@((prob*(1-prob))[:,None]*x)
    eig=np.linalg.eigvalsh(info)
    if not np.all(np.isfinite(res.x)) or np.max(np.abs(grad))>1e-5 or eig[0]<1e-10:
        return {'status':'nonconverged_or_singular','message':str(res.message),'score_max':float(np.max(np.abs(grad))),
                'information_min_eigenvalue':float(eig[0]),'separation':sep}
    return {'status':'finite','beta':res.x,'negative_log_likelihood':value,'score_max':float(np.max(np.abs(grad))),
            'information_min_eigenvalue':float(eig[0]),'separation':sep}

def wtp(beta,nonlinear=False,segment='low'):
    slope=beta[0]+(beta[8] if nonlinear and segment=='high' else 0)
    return np.array([-.1*sum(beta[i]*v for i,v in contrast.items())/slope for contrast in CONTRASTS.values()])

def collect_records(root):
    cfg=effective_configuration(root)
    review_path=root/'execution/reviewed_failures.json'
    reviews={(r['model'],r['episode_id']):r for r in json.loads(review_path.read_text())['failures']} if review_path.exists() else {}
    es={e['episode_id']:e for e in readl(root/'inputs/episodes.jsonl')};rows=[]
    for s in readl(root/'inputs/schedule.jsonl'):
        e=es[s['episode_id']];p=root/'runs'/s['model']/'responses'/(e['episode_id']+'.json')
        row={**s,'mandate':e['mandate'],'case_id':e['case_id'],'order':e['order'],'repeat_of':e['repeat_of'],
             'status':'missing','physical_choice':None,'display_choice':None,'cost_usd':'0'}
        if p.exists():
            raw=json.loads(p.read_text());m=cfg['models'][s['model']]
            assert raw['plan_manifest_sha256']==hashfile(root/'manifest.json')
            assert raw['prompt_sha256']==e['prompt_sha256'] and raw['request']==request(e,m)
            status,physical=parse(raw,e)
            row.update(status=status,physical_choice=physical,cost_usd=raw.get('accounted_cost_usd','0'),
                response_sha256=hashfile(p),started_utc=raw['started_utc'],ended_utc=raw.get('ended_utc'),
                request_state=raw['state'],provider=raw.get('provider'),returned_model=raw.get('returned_model'))
            review=reviews.get((s['model'],e['episode_id']))
            if review and raw['state']!='completed':
                assert hashfile(p)==review['original_response_sha256']
                assert hashfile(root/review['billing_evidence_path'])==review['billing_evidence_sha256']
                row.update(status='service_error',cost_usd=review['reconciled_cost_usd'],error=raw.get('error'))
            if status=='valid':row['display_choice']='DECLINE' if physical=='DECLINE' else 'AB'[e['order'].index(physical)]
            if raw['state']=='completed':
                assert D(str(raw['raw_response']['usage']['cost']))==D(raw['accounted_cost_usd'])
                assert raw['provider']==m['upstream_provider_name'] and raw['returned_model'] in m['expected_returned_model_ids']
            if e['stage']=='holdout':row['prediction_freeze_sha256']=raw.get('prediction_freeze_sha256')
        rows.append(row)
    return rows

def reliability(root,rows):
    cells=[]
    for model,mandate in itertools.product(MODELS,MANDATES):
        rr=[r for r in rows if r['model']==model and r['mandate']==mandate];lookup={r['episode_id']:r for r in rr}
        stage_counts={stage:dict(Counter(r['status'] for r in rr if r['stage']==stage)) for stage in ['controls','estimation','repeat','holdout']}
        order={}
        for stage in ['estimation','holdout']:
            disagreements=[];compared=0
            for cid in sorted({r['case_id'] for r in rr if r['stage']==stage}):
                rs=[r for r in rr if r['stage']==stage and r['case_id']==cid]
                if len(rs)==2 and all(r['status']=='valid' for r in rs):
                    compared+=1
                    if rs[0]['physical_choice']!=rs[1]['physical_choice']:disagreements.append(cid)
            order[stage]={'pairs':compared,'disagreements':len(disagreements),'case_ids':disagreements}
        repeat={'comparisons':0,'matches':0,'disagreements':[]}
        for r in rr:
            if r['stage']!='repeat':continue
            old=lookup[r['repeat_of']]
            if r['status']==old['status']=='valid':
                repeat['comparisons']+=1
                if r['physical_choice']==old['physical_choice']:repeat['matches']+=1
                else:repeat['disagreements'].append(r['episode_id'])
        cells.append({'model':model,'mandate':mandate,'planned_calls':len(rr),'statuses':dict(Counter(r['status'] for r in rr)),
            'stage_statuses':stage_counts,'declines':sum(r['physical_choice']=='DECLINE' for r in rr),
            'declines_by_stage':{s:sum(r['physical_choice']=='DECLINE' and r['stage']==s for r in rr) for s in stage_counts},
            'order':order,'repeat':repeat,'control_gate':control_gate(root,model,mandate),
            'cost_usd':str(sum(D(r['cost_usd']) for r in rr))})
    return cells

def score(p,y):
    p=np.asarray(p);best=np.isclose(p,p.max(),atol=1e-12,rtol=0)
    return np.array([-math.log(max(p[y],1e-300)),np.sum((p-np.eye(3)[y])**2),float(best[y])/sum(best)])

def analyze_prediction(root,rows):
    freeze=verify_freeze(root);content=json.loads((root/'predictions.json').read_text())
    holds=[r for r in rows if r['stage']=='holdout']
    assert all(r.get('prediction_freeze_sha256')==hashfile(root/'prediction_freeze.json') and r['started_utc']>freeze['created_utc'] for r in holds if r['status']=='valid')
    pm={(p['model'],p['episode_id']):p for p in content['predictions']}
    pair_ids=sorted({r['case_id'] for r in holds});cells=list(itertools.product(MODELS,MANDATES))
    # Index cell, physical pair, order, rule, metric.
    scores=np.full((9,len(pair_ids),2,len(RULES),3),np.nan);probabilities=np.full((9,len(pair_ids),2,3),np.nan)
    observed=np.full((9,len(pair_ids),2),np.nan)
    for r in holds:
        if r['status']!='valid':continue
        ci=cells.index((r['model'],r['mandate']));pi=pair_ids.index(r['case_id']);oi=['XY','YX'].index(r['order'])
        pr=pm[r['model'],r['episode_id']];y=['A','B','DECLINE'].index(r['display_choice']);observed[ci,pi,oi]=y
        for ri,rule in enumerate(RULES):scores[ci,pi,oi,ri]=score(pr['probabilities'][rule],y)
        displayed=np.array(pr['probabilities']['logit'])
        probabilities[ci,pi,oi]=displayed if oi==0 else displayed[[1,0,2]]
    draw=np.random.default_rng(2026111311).integers(0,len(pair_ids),size=(2000,len(pair_ids)))
    pairtotals=np.nansum(scores,axis=2);paircounts=np.sum(np.isfinite(scores[:,:,:,0,0]),axis=2)
    with np.errstate(invalid='ignore',divide='ignore'):
        means=pairtotals.sum(axis=1)/paircounts.sum(axis=1)[:,None,None]
        boots=pairtotals[:,draw,:,:].sum(axis=2)/paircounts[:,draw].sum(axis=2)[:,:,None,None]
    result=[]
    for ci,(model,mandate) in enumerate(cells):
        record={'model':model,'mandate':mandate,'planned_prediction_pairs':len(pair_ids),
                'prediction_pairs':int(sum(paircounts[ci]>0)),'complete_prediction_pairs':int(sum(paircounts[ci]==2)),
                'presentations':int(paircounts[ci].sum()),'unscored_presentations':int(2*len(pair_ids)-paircounts[ci].sum()),'scores':{},'logit_minus_benchmark':{}}
        for ri,rule in enumerate(RULES):
            record['scores'][rule]={metric:{'estimate':means[ci,ri,mi],'interval95':interval(boots[ci,:,ri,mi])} for mi,metric in enumerate(METRICS)}
            if ri:
                record['logit_minus_benchmark'][rule]={metric:{'estimate':means[ci,0,mi]-means[ci,ri,mi],
                    'interval95':interval(boots[ci,:,0,mi]-boots[ci,:,ri,mi])} for mi,metric in enumerate(METRICS)}
        result.append(record)
    comparisons=[]
    for a,b in itertools.combinations(range(9),2):
        if cells[a][0]!=cells[b][0] and cells[a][1]!=cells[b][1]:continue
        # A single magnitude avoids cancellation when a mandate switches some offers in each direction.
        comparable=np.isfinite(observed[a])&np.isfinite(observed[b]);counts=comparable.sum(axis=1)
        tvs=.5*np.abs(probabilities[b]-probabilities[a]).sum(axis=-1)
        tv=np.nansum(np.where(comparable,tvs,np.nan),axis=1)
        mismatch=np.sum((observed[b]!=observed[a])&comparable,axis=1)
        # Compare scores on exactly the same observed presentations. Marginal
        # cell averages can differ solely because their missing tasks differ.
        score_delta=np.nansum(np.where(comparable[:,:,None],scores[b,:,:,0,:]-scores[a,:,:,0,:],np.nan),axis=1)
        with np.errstate(invalid='ignore',divide='ignore'):
            tv_boot=tv[draw].sum(axis=1)/counts[draw].sum(axis=1)
            disagreement_boot=mismatch[draw].sum(axis=1)/counts[draw].sum(axis=1)
            score_delta_boot=score_delta[draw].sum(axis=1)/counts[draw].sum(axis=1)[:,None]
        comparisons.append({'a':cells[a],'b':cells[b],
            'comparable_presentations':int(counts.sum()),
            'mean_total_variation_in_prediction':float(tv.sum()/counts.sum()) if counts.sum() else None,'tv_interval95':interval(tv_boot),
            'observed_display_choice_disagreement':float(mismatch.sum()/counts.sum()) if counts.sum() else None,'disagreement_interval95':interval(disagreement_boot),
            'logit_score_difference_b_minus_a':{metric:{'estimate':score_delta[:,mi].sum()/counts.sum() if counts.sum() else None,
                'interval95':interval(score_delta_boot[:,mi])} for mi,metric in enumerate(METRICS)}})
    return serial({'freeze_valid':True,'freeze_utc':freeze['created_utc'],'first_holdout_request_utc':min(r['started_utc'] for r in holds if r.get('started_utc')),
        'pair_bootstrap_replicates':2000,'bootstrap_seed':2026111311,'cells':result,'paired_comparisons':comparisons,
        'unscored_holdout_statuses':dict(Counter(r['status'] for r in holds if r['status']!='valid')),
        'fitted_models':content['fits']})

def monetary_xy(rows,pairs,model,mandate,nonlinear):
    groups=[]
    for cid in [f'E{i:03}' for i in range(1,65)]:
        x=[];y=[]
        for r in rows:
            if r['model']==model and r['mandate']==mandate and r['stage']=='estimation' and r['case_id']==cid and r['status']=='valid' and r['physical_choice'] in ['X','Y']:
                a,b=r['order'];p=pairs[cid]['profiles'];x.append(np.r_[features(p[a],nonlinear)-features(p[b],nonlinear),1.]);y.append(r['physical_choice']==a)
        groups.append((np.asarray(x,dtype=float).reshape(-1,10 if nonlinear else 9),np.asarray(y,dtype=float)))
    return groups

def run_monetary(root,rows,replicates=1000):
    pairs={p['case_id']:p for p in readl(root/'inputs/physical_pairs.jsonl')};results=[];bootstrap_store={}
    draws=np.random.default_rng(2026111313).integers(0,64,size=(replicates,64))
    for model,mandate in itertools.product(MODELS,MANDATES):
        for nonlinear in [False,True]:
            form='hinge' if nonlinear else 'linear';groups=monetary_xy(rows,pairs,model,mandate,nonlinear)
            x=np.vstack([g[0] for g in groups]);y=np.concatenate([g[1] for g in groups]);fit=mle(x,y)
            rec={'model':model,'mandate':mandate,'fee_form':form,'purchase_presentations':len(y),
                 'complete_sample_fit':fit,'bootstrap_attempted':0,'bootstrap_fit_statuses':{},'monetary_status':'unidentified','tradeoffs':{}}
            if fit['status']=='finite':
                betas=np.full((replicates,x.shape[1]),np.nan);statuses=Counter()
                for i,draw in enumerate(draws):
                    xx=np.vstack([groups[j][0] for j in draw]);yy=np.concatenate([groups[j][1] for j in draw]);f=mle(xx,yy,start=fit['beta'])
                    statuses[f['status']]+=1
                    if f['status']=='finite':betas[i]=f['beta']
                rec['bootstrap_attempted']=replicates;rec['bootstrap_fit_statuses']=dict(statuses)
                segments=['low','high'] if nonlinear else ['low'];identified=[]
                for seg in segments:
                    slopes=betas[:,0]+(betas[:,8] if nonlinear and seg=='high' else 0)
                    point_slope=fit['beta'][0]+(fit['beta'][8] if nonlinear and seg=='high' else 0)
                    usable=np.all(np.isfinite(betas),axis=1)&(slopes<0)
                    ci=interval(slopes);good=point_slope<0 and ci[1] is not None and ci[1]<0 and usable.sum()/replicates>=.95
                    values=np.full((replicates,len(CONTRASTS)),np.nan)
                    for i in np.where(usable)[0]:values[i]=wtp(betas[i],nonlinear,seg)
                    record={'status':'identified' if good else 'unstable_or_unidentified','fee_slope':float(point_slope),
                        'fee_slope_interval95':ci,'finite_negative_fee_bootstrap_fits':int(usable.sum()),'bootstrap_replicates':replicates,
                        'contrasts':{}}
                    if good:
                        point=wtp(fit['beta'],nonlinear,seg)
                        for j,k in enumerate(CONTRASTS):record['contrasts'][k]={'estimate_usd':float(point[j]),'interval95_usd':interval(values[:,j])}
                        bootstrap_store[(model,mandate,form,seg)]=(values,point)
                        identified.append(seg)
                    rec['tradeoffs'][seg]=record
                rec['monetary_status']='identified_all_segments' if len(identified)==len(segments) else 'partly_identified' if identified else 'unstable_or_unidentified'
            else:rec['bootstrap_note']='No bootstrap monetary estimate: the complete sample fails finite-identification requirements.'
            results.append(serial(rec))
            save(root/'analysis/monetary_progress.json',{'completed_cells_and_forms':len(results),'expected':18,'latest':serial(rec)})
            print(json.dumps({'monetary_model':model,'mandate':mandate,'form':form,'status':rec['monetary_status'],'fit':fit['status']}),flush=True)
    comparisons=[]
    for a,b in itertools.combinations(bootstrap_store,2):
        if a[2:]!=b[2:] or (a[0]!=b[0] and a[1]!=b[1]):continue
        av,ap=bootstrap_store[a];bv,bp=bootstrap_store[b];paired=np.all(np.isfinite(av)&np.isfinite(bv),axis=1)
        comparisons.append({'a':a,'b':b,'paired_finite_bootstrap_fits':int(paired.sum()),
            'difference_b_minus_a_usd':{k:{'estimate':float(bp[j]-ap[j]),'interval95':interval((bv-av)[:,j])} for j,k in enumerate(CONTRASTS)}})
    return {'bootstrap_seed':2026111313,'replicates':replicates,'attribute_coding':NAMES,'contrast_order':list(CONTRASTS),
            'cells':results,'paired_comparisons':comparisons}

def ensure_monetary_results(root,rows,replicates=1000):
    estimation=[r for r in rows if r['stage']=='estimation']
    assert estimation and all(r['status'] in ['valid','service_error'] for r in estimation)
    signature={'plan_manifest_sha256':hashfile(root/'manifest.json'),
        'analysis_code_sha256':hashfile(Path(__file__)), 'replicates':replicates,
        'estimation_responses':{r['model']+'/'+r['episode_id']:{'sha256':r['response_sha256'],'status':r['status']} for r in estimation}}
    output=root/'analysis/monetary_results.json';proof=root/'analysis/monetary_input_manifest.json'
    if output.exists() and proof.exists():
        old=json.loads(proof.read_text())
        if old['inputs']==signature and old['result_sha256']==hashfile(output):
            print('Reusing completed monetary analysis on unchanged estimation data.',flush=True)
            return
    save(output,serial(run_monetary(root,rows,replicates)))
    save(proof,{'completed_utc':datetime.now(timezone.utc).isoformat(),'inputs':signature,'result_sha256':hashfile(output)})

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,default=ROOT);ap.add_argument('--replicates',type=int,default=1000);args=ap.parse_args()
    root=args.root;check_manifest(root);rows=collect_records(root);cfg=effective_configuration(root)
    phase=sum(D(r['cost_usd']) for r in rows);result={'analyzed_utc':datetime.now(timezone.utc).isoformat(),
        'plan_manifest_sha256':hashfile(root/'manifest.json'),'planned_calls':len(rows),'response_statuses':dict(Counter(r['status'] for r in rows)),
        'prior_cost_usd':cfg['prior_cost_usd'],'phase_cost_usd':str(phase),'cumulative_cost_usd':str(D(cfg['prior_cost_usd'])+phase),
        'phase_cap_usd':cfg['phase_cap_usd'],'cells':reliability(root,rows)}
    save(root/'analysis/observations.json',rows);save(root/'analysis/run_results.json',result)
    if (root/'prediction_freeze.json').exists() and any(r['stage']=='holdout' and r['status']=='valid' for r in rows):
        save(root/'analysis/prediction_results.json',analyze_prediction(root,rows))
    estimation=[r for r in rows if r['stage']=='estimation']
    if all(r['status'] in ['valid','service_error'] for r in estimation):
        ensure_monetary_results(root,rows,args.replicates)
    if any(r['status']!='valid' for r in rows):
        save(root/'analysis/incomplete_analysis.json',{'status':'first_attempt_failures_retained',
            'statuses':dict(Counter(r['status'] for r in rows if r['status']!='valid')),
            'treatment':'No replacement. Estimate with valid estimation purchases; score only observed valid holdout choices and explicitly report every denominator. Pair resampling retains both display positions and all conditions, including missing outcomes.'})
    print(json.dumps({'statuses':result['response_statuses'],'phase_cost_usd':str(phase)}))
if __name__=='__main__':main()

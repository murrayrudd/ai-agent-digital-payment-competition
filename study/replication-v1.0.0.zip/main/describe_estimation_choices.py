"""Descriptive recount of all common-offer contrasts in the estimation sample.

No additional model fitting, tests, or inference calls. Counts complement the
separate held-out prediction comparisons; exact repeats are excluded.
"""
from pathlib import Path
from datetime import datetime,timezone
import itertools,json
from runtime import ROOT,hashfile
from api_client import save

def main(root=ROOT):
    rows=json.loads((root/'analysis/observations.json').read_text())
    cells=list(itertools.product(['sol','qwen','claude'],['reference','cost','protection']))
    output=[]
    for a,b in itertools.combinations(cells,2):
        if a[0]!=b[0] and a[1]!=b[1]:continue
        a_choices={(r['case_id'],r['order']):r['physical_choice'] for r in rows
            if (r['model'],r['mandate'])==a and r['stage']=='estimation' and r['status']=='valid'}
        b_choices={(r['case_id'],r['order']):r['physical_choice'] for r in rows
            if (r['model'],r['mandate'])==b and r['stage']=='estimation' and r['status']=='valid'}
        common=a_choices.keys()&b_choices.keys()
        differences=sum(a_choices[k]!=b_choices[k] for k in common)
        output.append({'a':a,'b':b,'comparable_presentations':len(common),
            'choice_disagreements':differences,'disagreement_share':differences/len(common)})
    save(root/'analysis/estimation_choice_comparisons.json',{
        'created_utc':datetime.now(timezone.utc).isoformat(),
        'observations_sha256':hashfile(root/'analysis/observations.json'),
        'interpretation':'Descriptive counts on completed estimation offers; not held-out prediction scores or population-level causal estimates. Both display orders remain visible. DECLINE is a valid choice.',
        'contrasts':output})
    print('All 18 estimation-choice comparisons recounted.')

if __name__=='__main__':main()

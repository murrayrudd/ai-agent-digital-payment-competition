"""Parsing and provenance utilities. Importing makes no requests."""
from pathlib import Path
from decimal import Decimal as D
import hashlib, json

ROOT=Path(__file__).resolve().parent
def readl(p):return [json.loads(x) for x in p.read_text().splitlines() if x.strip()]
def hashfile(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def check_manifest(root):
    m=json.loads((root/'manifest.json').read_text())
    for f,h in m['files'].items():
        if hashfile(root/f)!=h:raise ValueError('Frozen input changed: '+f)
def request(e,m):
    return {'model':m['model_id'],'messages':e['messages'],'stream':False,
      'max_tokens':m['max_output_tokens'],
      'response_format':{'type':'json_schema','json_schema':{'name':'exploration_response','strict':True,'schema':e['response_schema']}},
      'provider':{'only':[m['upstream_provider']],'allow_fallbacks':False,'require_parameters':True,
        'data_collection':'deny','max_price':{'prompt':m['input_usd_per_million'],'completion':m['output_usd_per_million']}},
      'plugins':[{'id':x,'enabled':False} for x in ['web','response-healing','file-parser']],
      'transforms':[],'usage':{'include':True},**m['generation']}
def parse(record,e):
    if record.get('state')!='completed':return record.get('state','missing'),None
    if record.get('refusal'):return 'refusal',None
    if record.get('finish_reason')=='length':return 'truncation',None
    try:x=json.loads(record.get('raw_content') or '')
    except (ValueError,TypeError):return 'invalid_json',None
    sch=e['response_schema']
    if not isinstance(x,dict) or set(x)!=set(sch['required']):return 'invalid_schema',None
    for k,v in x.items():
        s=sch['properties'][k]
        if s['type']=='boolean' and type(v) is not bool:return 'invalid_schema',None
        if s['type']=='number' and (type(v) not in (int,float) or not D(str(v)).is_finite()):return 'invalid_schema',None
        if s['type']=='string' and (not isinstance(v,str) or v not in s['enum']):return 'invalid_schema',None
    if e['kind']=='factual':return 'valid',x
    return 'valid',e['display_map'][x['choice']]
def factual_correct(answer,key):
    for k,v in key['expected'].items():
        if isinstance(v,bool):
            if answer.get(k) is not v:return False
        elif abs(D(str(answer.get(k)))-D(str(v)))>D(str(key['absolute_tolerance'])):return False
    return True
def qualification(root):
    es=[e for e in readl(root/'inputs/episodes.jsonl') if e['stage']=='qualification']
    keys={k['case_id']:k for k in readl(root/'inputs/answer_key.jsonl')}
    rows=[];passed=True;purchase=0
    for e in es:
        p=root/'responses'/(e['episode_id']+'.json')
        if not p.exists():rows.append({'id':e['episode_id'],'status':'missing'});passed=False;continue
        status,value=parse(json.loads(p.read_text()),e)
        ok=status=='valid'
        if ok and e['kind']=='factual':ok=factual_correct(value,keys[e['case_id']])
        if ok and e['kind']=='cost_diagnostic':
            ok=value in ('Y','DECLINE');purchase+=int(value in ('X','Y'))
        passed=passed and ok
        rows.append({'id':e['episode_id'],'status':status,'value':value,'passes':ok})
    return {'passes':passed and purchase>0,'all_factual_and_cost_checks_pass':passed,
            'cost_diagnostic_purchases':purchase,'rows':rows}

def factual_gate(root, model):
    es=[e for e in readl(root/'inputs/episodes.jsonl') if e['stage']=='qualification']
    keys={k['case_id']:k for k in readl(root/'inputs/answer_key.jsonl')}
    rows=[]
    for e in es:
        p=root/'runs'/model/'responses'/(e['episode_id']+'.json')
        if not p.exists():rows.append({'id':e['episode_id'],'status':'missing','passes':False});continue
        status,value=parse(json.loads(p.read_text()),e)
        ok=status=='valid' and factual_correct(value,keys[e['case_id']])
        rows.append({'id':e['episode_id'],'status':status,'value':value,'passes':ok})
    return {'passes':len(rows)==7 and all(x['passes'] for x in rows),'rows':rows}

def control_gate(root, model, mandate):
    es=[e for e in readl(root/'inputs/episodes.jsonl') if e['stage']=='controls' and e['mandate']==mandate]
    rows=[]
    for e in es:
        p=root/'runs'/model/'responses'/(e['episode_id']+'.json')
        if not p.exists():rows.append({'id':e['episode_id'],'status':'missing','passes':False});continue
        status,value=parse(json.loads(p.read_text()),e)
        ok=status=='valid' and value in ('Y','DECLINE')
        rows.append({'id':e['episode_id'],'status':status,'value':value,'passes':ok})
    return {'passes':len(rows)==2 and all(x['passes'] for x in rows) and any(x.get('value')=='Y' for x in rows),'rows':rows}

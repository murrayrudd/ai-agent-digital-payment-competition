"""Fit and seal predictions before any held-out model call. No network access."""
from pathlib import Path
import json
import numpy as np
from scipy.optimize import minimize
from scipy.special import logsumexp, softmax
from features import options, expenditure
from runtime import readl, hashfile, parse, check_manifest
from api_client import save, now

LAMBDAS = [.01, .1, 1., 10.]

def objective(beta, x, y, penalty):
    v = x @ beta
    p = softmax(v, axis=1)
    loss = np.sum(logsumexp(v, axis=1)-v[np.arange(len(y)), y]) + .5*penalty*np.dot(beta,beta)
    residual = p.copy(); residual[np.arange(len(y)), y] -= 1
    grad = np.einsum('na,nak->k', residual, x) + penalty*beta
    return float(loss), grad

def fit(x, y, penalty):
    result = minimize(objective, np.zeros(x.shape[2]), args=(x,y,penalty), jac=True,
                      method='L-BFGS-B', options={'maxiter':2000,'gtol':1e-7,'ftol':1e-12})
    if not result.success or not np.all(np.isfinite(result.x)):
        raise RuntimeError('Predictive fit failed: '+str(result.message))
    return result.x

def benchmark(pair, order, kind):
    p = [pair['profiles'][v] for v in order]
    if kind=='fee': values=[float(v['fee']) for v in p]
    elif kind=='expenditure': values=[expenditure(v) for v in p]
    elif kind=='protection':
        # Lexicographic expected unrecoverable loss, fee, then identical tie probabilities.
        values=[(10*float(v['loss_probability'])+.01*(1-float(v['refund'])),float(v['fee'])) for v in p]
    else: raise ValueError(kind)
    best=min(values); tied=[i for i,v in enumerate(values) if v==best]
    probs=np.ones(3)*(.02/3)
    for i in tied: probs[i]+=.98/len(tied)
    return probs.tolist()

def training_data(root, model, mandate):
    es=readl(root/'inputs/episodes.jsonl')
    pairs={p['case_id']:p for p in readl(root/'inputs/physical_pairs.jsonl')}
    rows=[]; hashes={}; invalid=[]
    for e in es:
        if e['stage']!='estimation' or e['mandate']!=mandate: continue
        path=root/'runs'/model/'responses'/(e['episode_id']+'.json')
        if not path.exists(): raise RuntimeError('Estimation is incomplete.')
        rec=json.loads(path.read_text()); hashes[str(path.relative_to(root))]=hashfile(path)
        status,physical=parse(rec,e)
        if status!='valid': invalid.append({'episode_id':e['episode_id'],'status':status}); continue
        label=2 if physical=='DECLINE' else e['order'].index(physical)
        rows.append((e,pairs[e['case_id']],label))
    complete={p['case_id'] for p in pairs.values() if sum(e['case_id']==p['case_id'] for e,_,_ in rows)==2}
    if len(complete)<48: raise RuntimeError('Fewer than 48 complete estimation pairs; stop before holdout.')
    return rows,hashes,invalid

def verify_freeze(root):
    freeze=json.loads((root/'prediction_freeze.json').read_text())
    if freeze['plan_manifest_sha256']!=hashfile(root/'manifest.json'): raise RuntimeError('Prediction plan changed.')
    if freeze['predictions_sha256']!=hashfile(root/'predictions.json'): raise RuntimeError('Predictions changed.')
    for path,h in freeze['training_response_hashes'].items():
        if hashfile(root/path)!=h: raise RuntimeError('Training response changed after prediction freeze.')
    return freeze

def freeze_predictions(root):
    check_manifest(root)
    if (root/'prediction_freeze.json').exists(): return verify_freeze(root)
    es=readl(root/'inputs/episodes.jsonl')
    holds=[e for e in es if e['stage']=='holdout']
    cfg=json.loads((root/'inputs/configuration.json').read_text())
    for m in cfg['models']:
        if any((root/'runs'/m/'responses'/(e['episode_id']+'.json')).exists() for e in holds):
            raise RuntimeError('Holdout attempt exists without prior prediction freeze.')
    pairs={p['case_id']:p for p in readl(root/'inputs/physical_pairs.jsonl')}
    cvmap=json.loads((root/'inputs/cv_folds.json').read_text())
    fitted=[]; predictions=[]; hashes={}
    for model in cfg['models']:
        for mandate in json.loads((root/'inputs/mandates.json').read_text()):
            rows,hs,invalid=training_data(root,model,mandate);hashes.update(hs)
            y=np.array([r[2] for r in rows]); folds=np.array([cvmap[r[0]['case_id']] for r in rows])
            results=[]
            for nonlinear in [False,True]:
                x=np.array([options(p,e['order'],nonlinear) for e,p,_ in rows])
                for penalty in LAMBDAS:
                    losses=[]
                    for fold in range(4):
                        train=folds!=fold; test=~train
                        if not np.any(test): raise RuntimeError('Empty validation fold.')
                        beta=fit(x[train],y[train],penalty)
                        v=x[test]@beta
                        losses.extend((logsumexp(v,axis=1)-v[np.arange(sum(test)),y[test]]).tolist())
                    results.append({'nonlinear':nonlinear,'penalty':penalty,'cv_log_loss':float(np.mean(losses))})
            best=min(results,key=lambda v:(v['cv_log_loss'],v['nonlinear'],-v['penalty']))
            x=np.array([options(p,e['order'],best['nonlinear']) for e,p,_ in rows])
            beta=fit(x,y,best['penalty'])
            modal=(np.bincount(y,minlength=3)+1)/(len(y)+3)
            fitted.append({'model':model,'mandate':mandate,'selected':best,'coefficients':beta.tolist(),
                'cross_validation':results,'training_n':len(y),'invalid':invalid,
                'interpretation':'Regularized prediction coefficients; not monetary estimates.'})
            for e in holds:
                if e['mandate']!=mandate: continue
                pair=pairs[e['case_id']]
                predictions.append({'model':model,'mandate':mandate,'episode_id':e['episode_id'],
                    'case_id':e['case_id'],'order':e['order'],'labels':['A','B','DECLINE'],
                    'probabilities':{'logit':softmax(options(pair,e['order'],best['nonlinear'])@beta).tolist(),
                        'modal_display':modal.tolist(),
                        **{k:benchmark(pair,e['order'],k) for k in ['fee','expenditure','protection']}}})
    save(root/'predictions.json',{'created_utc':now(),'fits':fitted,'predictions':predictions})
    freeze={'created_utc':now(),'plan_manifest_sha256':hashfile(root/'manifest.json'),
        'predictions_sha256':hashfile(root/'predictions.json'),'training_response_hashes':hashes,
        'heldout_model_calls_before_freeze':0,'prediction_presentations':len(predictions)}
    save(root/'prediction_freeze.json',freeze)
    return freeze

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    print(json.dumps(freeze_predictions(parser.parse_args().root)))

"""Offline reader for the public model configuration."""
import json

def effective_configuration(root):
    return json.loads((root / "inputs" / "configuration.json").read_text())

"""Construct a common main-study design without calling any model."""
from pathlib import Path
from decimal import Decimal as D
from datetime import datetime, timezone
from collections import Counter
import copy, hashlib, importlib.util, itertools, json, random, sys
import numpy as np
from scipy.special import expit
from features import features, NAMES

ROOT = Path(__file__).resolve().parent
SEED = 2026111301
FIELDS = ['fee','loss_probability','refund','custody','identity']
def write(p, v):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(v, indent=2)+'\n')
def lines(p, rows):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(''.join(json.dumps(r, sort_keys=True, separators=(',',':'))+'\n' for r in rows))
def readl(p): return [json.loads(s) for s in p.read_text().splitlines() if s.strip()]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def key(p):
    return tuple(str(D(str(p[k])).normalize()) if k in FIELDS[:3] else p[k] for k in FIELDS)
def grade(p):
    return np.array([-float(p['fee']), -float(p['loss_probability']), float(p['refund']),
                     p['custody']=='operator', {'legal':0,'persistent':1,'transaction':2}[p['identity']]])
def admissible(a,b):
    different = [a[k] != b[k] for k in FIELDS]
    if sum(different) < 3 or sum(different[1:]) < 2: return False
    d = grade(a)-grade(b)
    return bool(np.any(d>0) and np.any(d<0))
def coverage(profiles, domain):
    return {k:{v:sum(str(p[k])==v for p in profiles) for v in values} for k,values in domain.items()}
def main():
    if any((ROOT/'runs').glob('*/responses/*.json')):
        raise SystemExit('Main observations exist; do not rebuild.')
    source = ROOT/'source_evidence'
    domain = json.loads((source/'next_design/candidate_domain.json').read_text())['attributes']
    all_profiles = readl(source/'next_design/candidate_profiles.jsonl')
    prior = set()
    prior_paths = [source/'inputs/physical_pairs.jsonl', source/'prior_choice_pilot/inputs/physical_pairs.jsonl', ROOT/'prior_joint_profiles.jsonl']
    for p in prior_paths:
        for pair in readl(p):
            prior.update(key(x) for x in pair['profiles'].values())
    available = [p for p in all_profiles if key(p) not in prior]
    rng = np.random.default_rng(SEED)
    # Reserve six previously unused profiles at every fee before choosing estimation pairs.
    hold_pool = []
    for f in domain['fee']:
        indices = [i for i,p in enumerate(available) if p['fee']==f]
        hold_pool.extend(int(i) for i in rng.choice(indices, 6, replace=False))
    hp = set(hold_pool)
    train_pool = [i for i in range(len(available)) if i not in hp]
    # Independent random holdout selection with basic fee coverage only.
    hold_pairs = None
    for attempt in range(10000):
        ids = list(rng.permutation(hold_pool)); chosen=[]
        while len(ids)>1 and len(chosen)<16:
            i=int(ids.pop())
            js=[int(j) for j in ids if admissible(available[i],available[j])]
            if not js: continue
            j=js[int(rng.integers(len(js)))]; ids.remove(j); chosen.append((i,j))
        used=[available[i] for p in chosen for i in p]
        if len(chosen)==16 and min(coverage(used,domain)['fee'].values())>=2:
            hold_pairs=chosen; break
    assert hold_pairs is not None
    # Monetary planning scenarios broaden pilot information rather than fit it.
    scenario_specs=[(1,0,.02,.01),(1,.03,.10,.05),(1,.08,.25,.10),
                    (2,0,.10,.01),(2,.03,.02,.05),(2,.08,.25,.10),
                    (5,0,.02,.10),(5,.03,.25,.05),(5,.08,.10,.01)]
    priors=[np.zeros(9)]; prior_records=[{'name':'zero_information_prior','coefficients':[0.]*9}]
    for i,(financial,custody,legal,link) in enumerate(scenario_specs):
        for scale in [.03,.10]:
            b=np.array([-.1, .09*financial, .099*financial, .005*financial,
                        .010*financial, custody, legal, legal+link, 0.])/scale
            priors.append(b); prior_records.append({'name':f'planning_{i+1}_scale_{scale}',
                'financial_multiplier':financial,'custody_value_usd':custody,'avoid_legal_id_value_usd':legal,
                'additional_avoid_linkage_value_usd':link,'logit_scale_usd':scale,'coefficients':b.tolist()})
    priors=np.array(priors)
    candidates=[(i,j) for ii,i in enumerate(train_pool) for j in train_pool[ii+1:] if admissible(available[i],available[j])]
    # Use a fixed candidate subsample to make the heuristic inexpensive to reproduce.
    candidates=[candidates[i] for i in rng.choice(len(candidates),min(12000,len(candidates)),replace=False)]
    diffs=np.array([features(available[i])-features(available[j]) for i,j in candidates])
    prob=expit(priors@diffs.T)
    weights=2*prob*(1-prob) # both orders, conditional on purchase
    information=np.repeat((np.eye(9)*1e-3)[None,:,:],len(priors),axis=0)
    chosen=[]; used=set(); counts=Counter(); valid=np.ones(len(candidates),dtype=bool)
    for step in range(64):
        inv=np.linalg.inv(information)
        leverage=np.einsum('ni,sij,nj->sn',diffs,inv,diffs,optimize=True)
        gains=np.mean(np.log1p(weights*leverage),axis=0)
        # Ensure four or more appearances of each fee, using a mild early balance incentive.
        if step<32:
            bonus=np.array([sum(max(0,4-counts[available[i]['fee']]) for i in pair) for pair in candidates])
            gains+=.015*bonus
        deficient=[f for f in domain['fee'] if counts[f]<4]
        if deficient and step>=48:
            hits=np.array([any(available[i]['fee'] in deficient for i in pair) for pair in candidates])
            gains[~hits]=-np.inf
        gains[~valid]=-np.inf
        idx=int(np.argmax(gains)); assert np.isfinite(gains[idx])
        pair=candidates[idx]; chosen.append(pair); used.update(pair)
        counts.update(available[i]['fee'] for i in pair)
        d=diffs[idx]; information+=weights[:,idx,None,None]*np.outer(d,d)[None,:,:]
        valid=np.array([not (i in used or j in used) for i,j in candidates])
    assert min(counts.values())>=4 and len(counts)==9
    # Repeat eight preselected estimation pairs spanning planning uncertainty.
    selected_diffs=np.array([features(available[i])-features(available[j]) for i,j in chosen])
    probs=expit(priors[1:]@selected_diffs.T)
    uncertainty=np.mean(probs*(1-probs),axis=0)
    order=np.argsort(uncertainty)
    repeat_indices=sorted([int(i) for i in order[:4]]+[int(i) for i in order[-4:]])
    pairs=[]
    for stage,ps in [('estimation',chosen),('holdout',hold_pairs)]:
        for n,(i,j) in enumerate(ps,1):
            pairs.append({'case_id':('E' if stage=='estimation' else 'H')+f'{n:03}',
                'stage':stage,'profiles':{'X':available[i],'Y':available[j]},
                'repeat_selected':stage=='estimation' and (n-1) in repeat_indices})
    sys.path.insert(0,str(ROOT/'qualification_evidence'))
    import baseline_instrument as old
    spec=importlib.util.spec_from_file_location('qualified_design',ROOT/'qualification_evidence/build_design.py')
    qualified=importlib.util.module_from_spec(spec);spec.loader.exec_module(qualified)
    control=copy.deepcopy(old.CONTROL);control.update(stage='controls',repeat_selected=False)
    pairs=[control]+pairs
    cfg=json.loads((source/'inputs/configuration.json').read_text())
    episodes=[]
    for mandate in old.MANDATES:
        for pair in pairs:
            for display in ['XY','YX']:
                eid=mandate+'__'+pair['case_id']+'_'+display
                e=old.episode(eid,qualified.choice(pair,display,mandate),old.schema(),
                    stage=pair['stage'],kind='cost_diagnostic' if pair['stage']=='controls' else 'joint_tradeoff',
                    case_id=pair['case_id'],mandate=mandate,order=display,
                    display_map={'A':display[0],'B':display[1],'DECLINE':'DECLINE'},repeat_of=None)
                episodes.append(e)
                if pair['repeat_selected']:
                    r=copy.deepcopy(e);r.update(episode_id=eid+'_repeat',stage='repeat',repeat_of=eid);episodes.append(r)
    prng=random.Random(SEED);schedule=[]
    for stage in ['controls','estimation','repeat','holdout']:
        group=[e for e in episodes if e['stage']==stage];prng.shuffle(group)
        for e in group:
            models=list(cfg['models']);prng.shuffle(models)
            for name in models:schedule.append({'index':len(schedule)+1,'stage':stage,'model':name,'episode_id':e['episode_id']})
    # Information comparison with random designs from the same pool and profile uniqueness constraint.
    final_info=information-np.eye(9)[None,:,:]*1e-3
    final_logdet=float(np.linalg.slogdet(final_info)[1].mean())
    random_scores=[]
    for _ in range(100):
        used_r=set(); ids=[]
        for ix in rng.permutation(len(candidates)):
            pair=candidates[int(ix)]
            if any(i in used_r for i in pair): continue
            ids.append(int(ix)); used_r.update(pair)
            if len(ids)==64: break
        dx=diffs[ids]; info=np.einsum('sn,ni,nj->sij',weights[:,ids],dx,dx)
        random_scores.append(float(np.linalg.slogdet(info)[1].mean()))
    order_matrix=np.vstack([np.c_[selected_diffs,np.ones(64)],np.c_[selected_diffs,-np.ones(64)]])
    diag={'seed':SEED,'candidate_profiles':len(all_profiles),'previous_profiles_in_domain':len(all_profiles)-len(available),
          'available_new_profiles':len(available),'reserved_holdout_pool_profiles':len(hold_pool),
          'candidate_pair_subsample':len(candidates),'training_pairs':64,'holdout_pairs':16,
          'repeat_pairs':8,'unique_training_profiles':128,'unique_holdout_profiles':32,
          'training_profile_overlap_with_holdout':0,'main_profile_overlap_with_previous_studies':0,
          'training_coverage':coverage([available[i] for pair in chosen for i in pair],domain),
          'holdout_coverage':coverage([available[i] for pair in hold_pairs for i in pair],domain),
          'difference_rank_with_fee_hinge_and_position':int(np.linalg.matrix_rank(order_matrix)),
          'difference_column_count':order_matrix.shape[1],
          'difference_matrix_condition_number':float(np.linalg.cond(order_matrix)),
          'information_min_eigenvalue_by_prior':np.linalg.eigvalsh(final_info)[:,0].tolist(),
          'mean_log_determinant':final_logdet,'random_design_mean_log_determinants':random_scores,
          'relative_geometric_D_information_vs_random_median':float(np.exp((final_logdet-np.median(random_scores))/9)),
          'design_criterion':'Mean log determinant over 19 specified conditional-purchase logit priors; constrained greedy heuristic with fee coverage. Not a global optimum or a power calculation.',
          'dominance_screen':'Exclude pairs weakly ordered on all five design directions: lower fee, lower loss, larger refund, operator keys, less identifying disclosure. This is a design convention, not a behavioral correctness rule.',
          'repeated_cases':[f'E{i+1:03}' for i in repeat_indices],
          'holdout_selection_attempts':attempt+1,'planned_calls':len(schedule)}
    write(ROOT/'inputs/configuration.json',cfg);write(ROOT/'inputs/mandates.json',old.MANDATES)
    write(ROOT/'inputs/attributes.json',{'levels':domain,'scenario':qualified.COMMON,'feature_names':NAMES})
    write(ROOT/'inputs/design_priors.json',prior_records)
    lines(ROOT/'inputs/physical_pairs.jsonl',pairs);lines(ROOT/'inputs/episodes.jsonl',episodes);lines(ROOT/'inputs/schedule.jsonl',schedule)
    write(ROOT/'design_validation.json',diag)
    print(json.dumps({k:v for k,v in diag.items() if k not in ['random_design_mean_log_determinants','information_min_eigenvalue_by_prior','training_coverage','holdout_coverage']}))
if __name__=='__main__': main()

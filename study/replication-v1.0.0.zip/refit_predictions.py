"""Repeat model selection using estimation responses only and compare all held-out probabilities."""
import json
import shutil
import sys
import tempfile
from pathlib import Path
import numpy as np
ROOT = Path(__file__).resolve().parent / 'main'
sys.path.insert(0, str(ROOT))
from predict import freeze_predictions
from runtime import hashfile, readl

with tempfile.TemporaryDirectory() as directory:
    work = Path(directory)
    shutil.copytree(ROOT / 'inputs', work / 'inputs')
    saved = json.loads((ROOT / 'predictions.json').read_text())
    episodes = [e for e in readl(ROOT / 'inputs/episodes.jsonl') if e['stage'] == 'estimation']
    for model in json.loads((ROOT / 'inputs/configuration.json').read_text())['models']:
        for e in episodes:
            rel = Path('runs') / model / 'responses' / (e['episode_id'] + '.json')
            (work / rel).parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(ROOT / rel, work / rel)
    # This temporary manifest covers the public refit inputs. The original freeze is verified separately.
    inputs = {str(p.relative_to(work)): hashfile(p) for p in (work / 'inputs').iterdir()}
    (work / 'manifest.json').write_text(json.dumps({'files': inputs}))
    freeze_predictions(work)
    new = json.loads((work / 'predictions.json').read_text())
    assert len(new['fits']) == len(saved['fits']) == 9
    for a, b in zip(new['fits'], saved['fits']):
        assert (a['model'], a['mandate']) == (b['model'], b['mandate'])
        assert (a['selected']['nonlinear'], a['selected']['penalty']) == (b['selected']['nonlinear'], b['selected']['penalty'])
    assert len(new['predictions']) == len(saved['predictions']) == 288
    for a, b in zip(new['predictions'], saved['predictions']):
        assert (a['model'], a['episode_id']) == (b['model'], b['episode_id'])
        for rule, probabilities in a['probabilities'].items():
            np.testing.assert_allclose(probabilities, b['probabilities'][rule], atol=1e-6, rtol=1e-6)
print("Refitted all nine models using estimation choices and verified 288 frozen predictions.")
